#include <stdio.h>

int main()
{
      for (int i = 41; i <= 45; i++)
      {
            for (int k = 41; k <= i; k++)
            {
                  printf(" %d", k);
                        }

            printf("\n");
      }

      return 0;
}
